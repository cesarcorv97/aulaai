
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const processLectureAudio = async (
  fileName: string,
  base64Audio: string,
  mimeType: string
): Promise<{ transcript: string; summary: string }> => {
  // Usar Gemini 3 Flash para procesamiento de audio y resumen eficiente
  const model = "gemini-3-flash-preview";

  const systemInstruction = `
    Eres un transcriptor educativo profesional y asistente académico.
    El usuario ha proporcionado una grabación de audio de una clase titulada "${fileName}".
    
    Tareas:
    1. Transcribe el contenido del audio de la forma más precisa posible en el idioma original detectado.
    2. Proporciona un resumen estructurado de la clase en ESPAÑOL que incluya:
       - Temas principales cubiertos
       - Conceptos clave explicados
       - Fechas, nombres o fórmulas importantes mencionados
       - Preguntas de estudio sugeridas
    
    Formatea la salida como un JSON válido con exactamente dos claves: "transcript" y "summary".
    El valor de "summary" debe estar en formato Markdown y redactado íntegramente en español.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Audio,
            },
          },
          {
            text: `Por favor, transcribe y resume esta grabación de clase: ${fileName}. Asegúrate de que la respuesta esté en formato JSON y el resumen en español.`,
          },
        ],
      },
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || "{}");
    return {
      transcript: result.transcript || "Transcripción no disponible.",
      summary: result.summary || "Resumen no disponible.",
    };
  } catch (error) {
    console.error("Error de procesamiento de Gemini:", error);
    throw new Error("No se pudo procesar la grabación de la clase. Por favor, asegúrate de que sea un archivo de audio válido.");
  }
};
